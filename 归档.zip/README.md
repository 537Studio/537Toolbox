# 537Toolbox

#### 介绍

537工具箱，一个方便的工具软件（尚在开发中）

#### 运行环境：

Windows7及以上

![537工具箱图标](537ToolboxLogo.png)

#### 文件/文件夹作用

tools：用于存放其它小工具

fonts：用于存放TrueType字体文件

include：一些需要使用的头文件

#### 开发环境

Python 3.8.1
